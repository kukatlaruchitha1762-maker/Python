# Replace vowels with a simple code
def translate(text):
    vowels = "aeiouAEIOU"
    result = []

    for character in text:
        if character in vowels:
            result.append("*")
        else:
            result.append(character)

    return "".join(result)

sentence = input("Enter a sentence: ")
print("Translated:", translate(sentence))
