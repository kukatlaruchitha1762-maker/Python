# Lists, tuples, and dictionaries
fruits = ["apple", "banana", "mango"]
fruits.append("orange")
print("Fruits:", fruits)
print("First fruit:", fruits[0])

coordinates = (10, 20)  # Tuples cannot be changed after creation
print("Coordinates:", coordinates)

student = {
    "name": "Ruchitha",
    "course": "Python",
    "level": "Beginner",
}
print("Student:", student)
print("Course:", student["course"])
