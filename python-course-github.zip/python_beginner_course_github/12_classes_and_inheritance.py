# Classes, objects, and inheritance
class Student:
    def __init__(self, name, course):
        self.name = name
        self.course = course

    def introduce(self):
        print(f"I'm {self.name}, and I'm learning {self.course}.")

class GraduateStudent(Student):
    def share_goal(self):
        print("My goal is to keep learning and build projects.")

student = Student("Ruchitha", "Python")
student.introduce()

graduate_student = GraduateStudent("Alex", "Computer Science")
graduate_student.introduce()
graduate_student.share_goal()
