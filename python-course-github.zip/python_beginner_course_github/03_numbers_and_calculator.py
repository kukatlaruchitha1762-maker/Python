# Numbers and a simple calculator
first = float(input("Enter the first number: "))
operator = input("Choose +, -, *, or /: ")
second = float(input("Enter the second number: "))

if operator == "+":
    result = first + second
elif operator == "-":
    result = first - second
elif operator == "*":
    result = first * second
elif operator == "/":
    if second == 0:
        result = None
        print("You cannot divide by zero.")
    else:
        result = first / second
else:
    result = None
    print("Unknown operator.")

if result is not None:
    print("Result:", result)
