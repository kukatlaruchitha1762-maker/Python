# Error handling and basic file writing/reading
from pathlib import Path

try:
    number = int(input("Enter a whole number: "))
    print("Double:", number * 2)
except ValueError:
    print("That was not a valid whole number.")

file_path = Path("sample_notes.txt")
file_path.write_text("I am practicing Python file handling.\n", encoding="utf-8")

content = file_path.read_text(encoding="utf-8")
print("Contents of sample_notes.txt:")
print(content)
