# Functions and return values
def greet(name):
    return f"Hello, {name}!"

def power(base, exponent):
    return base ** exponent

print(greet("Python learner"))
print("2 to the power of 5 is", power(2, 5))
