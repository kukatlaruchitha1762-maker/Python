# A 2D list and nested loops
grid = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
]

for row in grid:
    for item in row:
        print(item, end=" ")
    print()
