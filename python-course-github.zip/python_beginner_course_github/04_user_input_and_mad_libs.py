# A tiny Mad Libs game
name = input("Enter a person's name: ")
adjective = input("Enter an adjective: ")
place = input("Enter a place: ")
verb = input("Enter a verb ending in -ing: ")

print(f"One day, {name} went to {place}.")
print(f"It was a very {adjective} day, and everyone was {verb}!")
