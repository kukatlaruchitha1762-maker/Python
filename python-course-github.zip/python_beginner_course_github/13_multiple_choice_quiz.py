# A small multiple-choice quiz
questions = [
    {
        "question": "Which keyword defines a function in Python?",
        "options": ["A. func", "B. def", "C. function"],
        "answer": "B",
    },
    {
        "question": "Which type stores key-value pairs?",
        "options": ["A. list", "B. tuple", "C. dictionary"],
        "answer": "C",
    },
    {
        "question": "Which symbol starts a comment?",
        "options": ["A. #", "B. //", "C. <!--"],
        "answer": "A",
    },
]

score = 0
for item in questions:
    print("\n" + item["question"])
    for option in item["options"]:
        print(option)

    answer = input("Your answer (A/B/C): ").strip().upper()
    if answer == item["answer"]:
        print("Correct!")
        score += 1
    else:
        print("Not quite. The answer is", item["answer"])

print(f"\nYour score: {score}/{len(questions)}")
