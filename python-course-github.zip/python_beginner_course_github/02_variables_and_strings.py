# Variables and strings
name = "Ruchitha"
age = 19

print("Name:", name)
print("Age:", age)
print(f"Hello, {name}!")

message = "Learning Python is fun"
print(message.upper())
print(message.lower())
print("Number of characters:", len(message))
print(message.replace("fun", "useful"))
