# First Python program
print("Hello, world!")
print("I'm learning Python.")
