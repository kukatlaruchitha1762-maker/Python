# Conditions, for loops, and while loops
number = int(input("Enter an integer: "))

if number > 0:
    print("Positive")
elif number < 0:
    print("Negative")
else:
    print("Zero")

print("Counting from 1 to 5:")
for value in range(1, 6):
    print(value)

count = 3
while count > 0:
    print("Countdown:", count)
    count -= 1
print("Go!")
