# Python Beginner Course — Practice Files

A beginner-friendly Python practice repository covering topics from the freeCodeCamp video
[Learn Python - Full Course for Beginners](https://youtu.be/rfscVS0vtbw).

These are original practice examples organized by topic, not a copy of the instructor's exact source files.

## Topics
- Hello World and drawing a shape
- Variables, strings, numbers, and user input
- Basic calculator and Mad Libs
- Lists, tuples, dictionaries, and loops
- Functions and return values
- If statements and comparisons
- Guessing game and exponent function
- 2D lists and nested loops
- Simple translator
- Try/except error handling
- Reading and writing files
- Classes, objects, and inheritance
- Multiple-choice quiz

## Requirements
- Python 3.10 or newer recommended
- No third-party packages required

## Run a file
Open a terminal in this folder and run, for example:

```bash
python 01_hello_world.py
```

On some systems, use `python3` instead of `python`.

## Suggested GitHub repository name
`python-beginner-course-practice`

## Note
Practice and modify the examples yourself before using them in a portfolio. Add your own notes, improvements, and projects as you learn.
